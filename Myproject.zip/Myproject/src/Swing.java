
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Swing extends JFrame implements ActionListener
{     
    ///   JPanel jp = new JPanel();
       JLabel jl = new JLabel();
       JPanel jp = new JPanel();
       JButton myButton = new JButton("Next Button");
       public  Swing()
       {
              setTitle("Tutorial");
              setVisible(true);
              setSize(1200, 800);
              setDefaultCloseOperation(EXIT_ON_CLOSE);

              jl.setIcon(new ImageIcon("D:\\c.jpg"));
              jp.add(jl);
              add(jp);

              validate();
              myButton.setBounds(1000,600,200,40);
        	  myButton.setFocusable(false);
        	  myButton.addActionListener(this);
        	  
        	  jp.add(myButton);
        	  
        	//  jp.setDefaultCloseOperation( JPanel.EXIT_ON_CLOSE);
        	  jp.setSize(1200,800);
        	  jp.setLayout(null);
        	  jp.setVisible(true);
       }
       public void actionPerformed(ActionEvent e) {
  		 if(e.getSource()==myButton) {
  			  // jp.dispose();
  			   MyProject myWindow = new MyProject();
  		
  	}
  }
}
