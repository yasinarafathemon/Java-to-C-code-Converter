
public class Main {

	public static void main(String[] args) {
		Swing t = new Swing();
		 ///LaunchPage launchPage = new LaunchPage();

	}

}