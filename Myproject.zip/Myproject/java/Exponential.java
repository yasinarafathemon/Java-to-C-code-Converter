import java.util.InputMismatchException;
import java.util.Scanner;

public class Exponential {


        public static void main(String[] args) throws Exception {
            System.out.println("\n\n\t\tStudytonight - Best place to learn\n\n\n");
            boolean done = false;
            do {
                try { int exp1;
                    System.out.println("Enter the number and it's exponential:\t");
                    Scanner in = new Scanner(System.in);
                    int n = in.nextInt();

                    int exp=in.nextInt();

                    long  value = 1;

                    exp1 = exp;   // storing original value for future use

                    // same as while((--exp)!=-1)
                    while(exp-- > 0)
                    {
                        value *= n; // multiply n to itself exp times
                    }

                    System.out.println("\n\t"+n+"^"+exp1+"=\t"+value);


                    System.out.println("\n\n\t\t\t Coding is Fun!\n\n\n");
                    done=true;
                } catch (InputMismatchException e) {
                    System.out.println("wrong taken");
                }
            } while (!done);
        }
    }

