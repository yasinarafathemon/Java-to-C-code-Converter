
		JAVA PROGRAM

import java.util.Scanner;

public class LeapYear {
    public static void main(String[] args) {
        System.out.println("\n\n\t\tStudytonight - Best place to learn\n\n\n");
        boolean done = false;
        Scanner sc = new Scanner(System.in);
            try {
                System.out.println(" Enter a year to check if it's leap year :");
                int year = sc.nextInt();
                sc.close();
                if (year != 0) {
                    if (year % 400 == 0) {
                        System.out.println(year + " is a leap year");
                    } else if (year % 100 == 0) {
                        System.out.println(year + " is not a leap year");
                    } else if (year % 4 == 0) {
                        System.out.println(year + " is a leap year");
                    } else {
                        System.out.println(year + " is not a leap year");
                    }
                } else {
                    throw new Exception();
                }
            } catch (Exception e) {
                System.out.println("Year 0 has no existence ");
            }
            System.out.println("\n\n\t\t\tCoding is Fun !\n\n\n");

    }
}

