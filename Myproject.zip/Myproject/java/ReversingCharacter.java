
		JAVA PROGRAM


import java.util.Scanner;

public class ReversingCharacter {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("\n\n\t\tStudytonight - Best place to learn\n\n\n");

        char alphabet;
        try{
        System.out.println("Enter an alphabet : ");
        alphabet = sc.next().charAt(0);
        System.out.println("\n\nReverse case of "+ alphabet + "\t is :" );

        if (Character.isLowerCase(alphabet)) {
            System.out.println(Character.toUpperCase(alphabet) );
        } else  {
            System.out.println(Character.toLowerCase(alphabet) );
        }
        throw new Exception();

    } catch (java.lang.Exception e) {
            System.out.println("Invalid");
        }
        System.out.println("\n\n\t\t\tCoding is Fun !\n\n\n");



    }}






