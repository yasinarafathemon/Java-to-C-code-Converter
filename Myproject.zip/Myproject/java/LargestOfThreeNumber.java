
		JAVA PROGRAM

import java.text.DecimalFormat;
import java.util.InputMismatchException;
import java.util.Scanner;

public class LargestOfThreeNumber {
    public static void main(String args[]) {
        System.out.println("\n\n\t\tStudytonight - Best place to learn\n\n\n");
        double x, y, z;boolean done=false;
        do {
            try {
                System.out.println("Enter 3 integers:");
                Scanner in = new Scanner(System.in);


                x = in.nextDouble();
                y = in.nextDouble();
                z = in.nextDouble();
                DecimalFormat df = new DecimalFormat("0.000");
                if (x > y && x > z){
                    System.out.println(" Largest number is:"+(df.format(x)));

                }
                else if (y > x && y > z)
                    System.out.println("Largest number is:" +(df.format(x))) ;
                else if (z > x && z > y)
                    System.out.println("Largest number is: " +(df.format(x))) ;

                done=true;
            } catch (InputMismatchException e) {
                System.out.println(" you didn't enter an integer");

            }
        } while (!done);
        System.out.println("\n\n\n\n\t\t\tCoding is Fun !\n\n\n\t\t");
    }
}