
		JAVA PROGRAM

import java.util.InputMismatchException;
import java.util.Scanner;

public class InsertElementToArray {

//Program to insert an element to array


        public static void main(String[] args) {
            System.out.println("\n\n\t\tStudytonight - Best place to learn\n\n\n");
            int n, pos, x; boolean done=false;
            Scanner s = new Scanner(System.in);
            do{
                try {
                    System.out.println("Enter the number of  elements in array:");
                    n = s.nextInt();
                    int a[] = new int[n + 1];

                    System.out.println("Enter " + n + "the elements:");

                    for (int i = 0; i < n; i++) {
                        a[i] = s.nextInt();
                    }
                    System.out.print("Enter the location where you want to insert element:");
                    pos = s.nextInt();

                    System.out.print("Enter the value  to insert:");
                    x = s.nextInt();
                    for (int i = (n - 1); i >= (pos - 1); i--) {
                        a[i + 1] = a[i];
                    }
                    a[pos - 1] = x;
                    System.out.print("Resultant array:");
                    for (int i = 0; i < n; i++) {
                        System.out.print(a[i] + ",");
                    }
                    System.out.print(a[n]);
                    done=true;
                } catch (InputMismatchException e) {
                    System.out.println(" you didn't enter an integer");
                } catch (ArrayIndexOutOfBoundsException e) {
                    System.out.println("Index  out of bounds for length ");
                }
            }while(!done);
            System.out.println("\n\n\n\n\t\t\tCoding is Fun !\n\n\n\t\t");
        }
    }




