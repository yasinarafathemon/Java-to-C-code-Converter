
		JAVA PROGRAM

import java.text.DecimalFormat;
import java.util.InputMismatchException;
import java.util.Scanner;

public class SecondLargestAmongThreeNum {
    import java.text.DecimalFormat;
import java.util.InputMismatchException;
import java.util.Scanner;

    public class SecondLargestAmongThreeNumber {
        public static void main(String[] args) {
            System.out.println("\n\n\t\tStudytonight - Best place to learn\n\n\n");

            double a, b, c;boolean done=false;
            Scanner in=new Scanner(System.in);
            do{
                try{
                    System.out.println("Enter 3 numbers:");
                    a = in.nextDouble();
                    b = in.nextDouble();
                    c= in.nextDouble();

                    DecimalFormat df = new DecimalFormat("0.00");
                    if (a >= b && a >= c) {
                        if (b >= c) {

                            System.out.println((df.format(b))+"\n\n is the 2nd largest number\n" );
                        } else {
                            System.out.println((df.format(a))+"\n\n is the 2nd largest number\n");
                        }
                    } else if (b >= a && b >= c) {
                        if (a >= c) {
                            System.out.println((df.format(a))+"\n\n is the 2nd largest number\n");
                        } else {
                            System.out.println((df.format(c))+"\n\n is the 2nd largest number\n");
                        }
                    }

                    // c is the largest number of the three
                    else if (a >= b) {
                        System.out.println ((df.format(a))+"\n\n is the 2nd largest number\n");
                    } else {
                        System.out.println((df.format(b))+"\n\n is the 2nd largest number\n");
                    }

                    done=true;
                }catch (InputMismatchException e) {
                    System.out.println(" you didn't enter an integer");

                }
            } while (!done);
            System.out.println("\n\n\n\n\t\t\tCoding is Fun !\n\n\n\t\t");
        }
    }

}
