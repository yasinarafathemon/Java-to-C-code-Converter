
		JAVA PROGRAM

import java.util.InputMismatchException;
import java.util.Scanner;

public class FactorOfNumber {
//Print Factor of a number

        public static void main(String[] args) {

            System.out.println("\n\n\t\tStudytonight - Best place to learn\n\n\n");
            int i = 0;boolean done=false;
            System.out.println("Enter the number to find the factors of :  ");
            do {
                try {
                    Scanner sc = new Scanner(System.in);
                    int num = sc.nextInt();

                    System.out.println("\n\n\nFactors of " + num + "\t are \n\n");

                    for (i = 1; i <= num / 2; i++) {
                        if (num % i == 0)
                            System.out.println("\t\t" + i + "\t\t\t");
                    }

                    done=true;
                } catch (InputMismatchException e) {
                    System.out.println(" you didn't enter an integer");
                }

            }while(!done);
            System.out.println("\n\n\n\n\t\t\tCoding is Fun !\n\n\n\t\t");
        }

}
