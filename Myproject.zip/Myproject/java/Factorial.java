

		JAVA PROGRAM


import java.util.Scanner;

public class factorial {
	
	public int getfact(int aj){
		
		if(aj==1 || aj==0)
	        return 1;
	    else
	        return (aj*getfact(aj-1));
		
		
	}

}
public class testfact {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 System.out.println("\n\n\t\tStudytonight - Best place to learn\n\n\n");
		    int num;
		    Scanner input = new Scanner(System.in);
		    System.out.println("\n\nEnter a number: ");
		 num=input.nextInt();
		  factorial f= new factorial();
		    System.out.println("\n\nFactorial of "+num+" is "+f.getfact(num));
		    System.out.println("\n\n\t\t\tCoding is Fun !\n\n\n");
		  
		}
}
