
		JAVA PROGRAM

import java.util.Scanner;

public class SumOfDigit {
//program to find sum of digit

    public static void main(String[] args) {
        boolean done = false;

        System.out.println("\n\n\t\tStudytonight - Best place to learn\n\n\n");
        do {
            try {
                Scanner sc = new Scanner(System.in);
                int sum = 0, c, remainder;

                System.out.println("Enter the number you want to add digits of:");
                int n = sc.nextInt();
                while (n != 0) {
                    remainder = n % 10;
                    sum += remainder;
                    n = n / 10;
                }
                System.out.println("\n\nSum of the digits of the entered number is =\t" + sum);
                System.out.println("\n\n\n\n\t\t\tCoding is Fun !\n\n\n");

                done = true;
            } catch (java.lang.Exception e) {
                System.out.println(" Don't find only numeric number ");
            }
        } while (!done);

    }
}
