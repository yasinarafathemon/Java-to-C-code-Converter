
		JAVA PROGRAM

import java.util.InputMismatchException;
import java.util.Scanner;

public class LargestSmallestNumber {
//Largest and Smallest element in Array

        public static void main(String[] args) {
            System.out.println("\n\n\t\tStudytonight - Best place to learn\n\n\n");
            boolean done = false;
            do {
                try {
                    int a[] = new int[50];
                    int i, big, small;
                    Scanner sc = new Scanner(System.in);
                    System.out.println("Enter the size of the array:");
                    int size = sc.nextInt();

                    System.out.println("\n\nEnter the\t" + size + "\telements of the array: \n\n");
                    for (i = 0; i < size; i++) {
                        a[i] = sc.nextInt();
                    }big = a[0]; // initializing
                    for (i = 1; i < size; i++) {
                        if (big < a[i])   // if larger value is encountered
                        {
                            big = a[i]; // update the value of big
                        }
                    }
                    System.out.println("\n\nThe largest element is:" + big + "\n");

                    small = a[0];   // initializing
                    for (i = 1; i < size; i++) {
                        if (small > a[i])   // if smaller value is encountered
                        {
                            small = a[i];   // update the value of small
                        }
                    }
                    System.out.println("\n\nThe smallest element is: " + small + "\n");
                    System.out.println("\n\n\t\t\tCoding is Fun !\n\n\n");

                    done=true;
                } catch (InputMismatchException e) {
                    System.out.println("wrong");
                }
                class InputMismatchException extends RuntimeException {
                    void InputMismatchingException() {
                        System.out.println("wrong");
                    }

                    InputMismatchException(String msg) {
                        super(msg);
                    }

                }

            } while (!done);
            System.out.println("\n\n\t\t\tCoding is Fun !\n\n\n");
        }
    }


