
		JAVA PROGRAM

import java.util.Scanner;

public class FactorialNumber {
//Program to find Factorial of number using exceptional handling

    public static void main(String args[]) {
        int num, i, fact = 1;
        boolean done = false;
        do {
            try {
                Scanner scan = new Scanner(System.in);

                System.out.print("Enter a Number : ");
                num = scan.nextInt();

                for (i = num; i > 0; i--) {
                    fact = fact * i;
                }

                System.out.print("Factorial of " + num + " is " + fact);
                done = true;
            } catch (Exception e) {
                System.out.println("number is out of bound");
            }
        } while (!done);
    }
}




