
		JAVA PROGRAM

import java.util.Scanner;
import java.io.IOException;

public class PalindromeProgram {
//palindrome series program

    public static void main(String[] args) {
        boolean done = false;


        do {
            try {
                Scanner sc = new Scanner(System.in);
                System.out.println("Enter the numbers:");
                int num = sc.nextInt();
                int reversedNum = 0, remainder;
                int originalNum = num;
                while (num != 0) {
                    remainder = num % 10;
                    reversedNum = reversedNum * 10 + remainder;
                    num /= 10;
                }

                // check if reversedNum and originalNum are equal
                if (originalNum == reversedNum) {
                    System.out.println(originalNum + "\t number is Palindrome.");
                } else {
                    System.out.println(originalNum + "\t number is not Palindrome.");
                }
                done = true;
            } catch (java.lang.Exception e) {
                System.out.println("Exception: " + e);
            }
        } while (!done);

    }
}
