

		JAVA PROGRAM

import java.util.Scanner;

public class MultiplicationTable {
//Program to print the multiplication table of any number

        public static void main(String[] args) throws Exception {
            boolean done = false;
            do {
                int i;
                System.out.println("\n\n\t\tStudytonight-Best place to learn\n\n\n");

                try {
                    Scanner s = new Scanner(System.in);
                    System.out.print("Enter an integers you need to print the table:");
                    int n = s.nextInt();
                    for (i = 1; i <= 10; i++) {
                        System.out.println("\n\t\t" + n + " * " + i + " =" + n * i + "");
                    }
                    done=true;
                } catch (java.lang.Exception e) {
                    System.out.println("Error ");
                }
                System.out.println("\n\n\t\t\tCoding is Fun !\n\n\n");
            } while (!done);


        }

    }


