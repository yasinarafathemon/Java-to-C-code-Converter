
		JAVA PROGRAM

import java.util.Scanner;

public class CheakingForGrade {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);


        System.out.println("\n\n\t\tStudytonight-Best place to learn\n\n\n");
        System.out.print("Enter grade : \n");

        String str = scanner.next();
        char grade = str.charAt(0);
        try {

            switch (grade) {
                case 'A':
                    System.out.println("Excellent\n");
                    break;
                case 'B':
                    System.out.println("Keep it up!\n\n");
                    break;
                case 'C':
                    System.out.println("Well done\nbreak keyword takes execution to exit the switch case\n\n");
                    break;
                case 'D':
                    System.out.println("You passed\n");
                    break;
                case 'F':
                    System.out.println("Better luck next time\n");
                    break;

                default:
                    if(grade<'F'||grade>'A'){
                        throw new java.lang.Exception() ;
                    }

            }
            System.out.println("Your grade is\n" + grade);
            System.out.println("\n\n\t\t\tCoding is Fun !\n\n\n");

        } catch (java.lang.Exception e) {
            System.out.println("Invalid grade\n");
        }

    }

}


