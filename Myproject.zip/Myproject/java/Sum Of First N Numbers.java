
	JAVA PROGRAM


import java.util.Scanner;

public class sumoffirstNnumbers {	
	int sum=0;


}
 class getsumm extends  sumoffirstNnumbers{
	
	
	public int getsum(int aj) {
	

		    while(aj > 0)
		    {
		        sum = sum + aj;
		        aj--;
	        
		    }
		    return sum ;
	   }
}
public class testsumoffirstNnumbers {
	public static void main(String[] args) {
	 	System.out.println("\n\n\t\tStudytonight - Best place to learn\n\n\n");
	    int n;
	    System.out.println("\n\nEnter the range of n: ");
	    Scanner input=new Scanner(System.in);
	    n=input.nextInt();
	    sumoffirstNnumbers s = new getsumm ();  //POLYMORPHYSIUM
	    getsumm s1= (getsumm)s;   //TYPE CASTING
	    System.out.println("\n\nThe sum of first "+n+" numbers is "+ s1.getsum(n));
	    System.out.println("\n\n\t\t\tCoding is Fun !\n\n\n");
	    
 }
}

