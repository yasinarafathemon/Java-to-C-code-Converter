
		JAVA PROGRAM

import java.util.Scanner;

public class ReverseAString {
    //how to reverse a string using for loop
    public static void main(String[] args) {
        String s = null;
        boolean done = false;
        do {
            try {
                Scanner sc = new Scanner(System.in);
                System.out.print(" String Before Reverse: ");
                s = sc.nextLine();                    //reading string from user
                System.out.print("String After reverse : ");
                for (int i = s.length(); i > 0; --i)                //i is the length of the string
                {
                    System.out.print(s.charAt(i - 1));
                }
                done = true;
            } catch (java.lang.Exception e) {
                System.out.println("String can't have 0 character " + e.getMessage());
            }


        } while (!done);

    }
}
