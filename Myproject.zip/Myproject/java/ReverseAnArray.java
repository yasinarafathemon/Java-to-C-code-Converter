
		JAVA PROGRAM


import java.util.InputMismatchException;
import java.util.Scanner;

public class ReverseAnArray {

//Program to print the reverse of array


        public static void main(String[] args) {
            System.out.println("\n\n\t\tStudytonight - Best place to learn\n\n\n");
            boolean done = false;
            int i, n;
            do {
                try {
                    Scanner sc = new Scanner(System.in);
                    System.out.println("Enter  number of elements in array:");
                    n = sc.nextInt();
                    int[] a = new int[n];
                    int[] reverse = new int[n];

                    System.out.println("\n\nEnter\t" + n + " elements");
                    for (i = 0; i < n; i++) {
                        a[i] = sc.nextInt();
                    }

                    for (i = 0; i < n; i++) {
                        reverse[i] = a[n - i - 1];
                    }
                    System.out.println("\n\n\tResultant array is:");
                    for (i = 0; i < n; i++) {
                        System.out.print(reverse[i] + " ");

                    }
                    done = true;
                } catch (ArrayIndexOutOfBoundsException e) {
                    System.out.println("Index -1 out of bounds for length 50");
                } catch (InputMismatchException e) {
                    System.out.println(" you didn't enter an integer");

                }
            } while (!done);
            System.out.println("\n\n\n\n\t\t\tCoding is Fun !\n\n\n\t\t");
        }

    }
