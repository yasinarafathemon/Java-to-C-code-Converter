
		JAVA PROGRAM


import java.util.InputMismatchException;
import java.util.Scanner;

public class DeleteElementsFromArray {

//Program to delete an element from array

        public static void main(String[] args) {
            System.out.println("\n\n\t\tStudytonight - Best place to learn\n\n\n");
            Scanner sc = new Scanner(System.in);
            int n;    //Array Size Declaration

            try{

                System.out.println("Enter the number of elements in array :");
                n = sc.nextInt();    //Array Size Initialization

                Integer arr[] = new Integer[n];    //Array Declaration
                System.out.println("Enter\t"+n+"\t elements  :");
                for (int i = 0; i < n; i++)     //Array Initialization
                {
                    arr[i] = sc.nextInt();
                }
                System.out.println("Enter the location where you want to delete element from: ");
                int elem = sc.nextInt();

                for (int i = 0; i < arr.length; i++) {
                    if (arr[i] == elem)   //If element found
                    {
                        // shifting elements
                        for (int j = i; j < arr.length - 1; j++) {
                            arr[j] = arr[j + 1];
                        }
                        break;
                    }
                }

                System.out.println("Resultant array: ");
                for (int i = 0; i < arr.length - 1; i++) {
                    System.out.print(arr[i] + " ");
                }
            }catch (InputMismatchException e) {
                System.out.println(" you didn't enter an integer");
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Index  out of bounds for length ");
            }
            System.out.println("\n\n\n\n\t\t\tCoding is Fun !\n\n\n\t\t");
        }
    }


