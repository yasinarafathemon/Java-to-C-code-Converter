
		JAVA PROGRAM

import java.util.InputMismatchException;
import java.util.Scanner;

public class SumOfNNumberArray {
//Program to find Sum of input number using array

        public static void main(String[] args) {
            System.out.println("\n\n\t\tStudytonight - Best place to learn\n\n\n");
            boolean done=false;
            do{
                try{
                    Scanner sc = new Scanner(System.in);
                    int c, sum = 0; int[] a = new int[50];
                    System.out.println("Enter the number of integers you want to add:");
                    int n = sc.nextInt();

                    System.out.println("\n\nEnter\t" + n + "\tintegers");
                    for (c = 0; c < n; c++) {
                        a[c] = sc.nextInt();
                        sum = sum + a[c];
                    }System.out.println("Sum   = " + sum);
                    done=true;
                } catch (InputMismatchException e) {
                    System.out.println(" you didn't enter an integer");
                }catch(ArrayIndexOutOfBoundsException e){
                    System.out.println("Index -1 out of bounds for length 50");
                }

            }while(!done);
            System.out.println("\n\n\n\n\t\t\tCoding is Fun !\n\n\n\t\t");
        }
    }


