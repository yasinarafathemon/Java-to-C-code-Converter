
		JAVA PROGRAM

import java.util.Scanner;

public class FibonacciSeries {

//Fibonacci Series Program using Exceptions Handling

    public static void main(String[] args) {
        boolean done = false;

        do {
            try {
                Scanner sc = new Scanner(System.in);
                int t1 = 0, t2 = 1;
                System.out.print("Enter the number of terms: ");
                int n = sc.nextInt();   //Declare and Initialize the number of terms

                //Print the fibonacci series
                int i = 1;
                do {
                    System.out.print(t1 + " ");
                    int sum = t1 + t2;
                    t1 = t2;
                    t2 = sum;
                    i++;
                    done=true;
                } while (i <= n);
            } catch (java.lang.Exception e) {
                System.out.println("Error ");
            }

        } while (!done);

    }
}
