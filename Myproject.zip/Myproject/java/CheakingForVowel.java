
		JAVA PROGRAM

import java.util.Scanner;

public class CheakingForVowel {
    public static void main(String[] args) {
        System.out.println("\n\n\t\tStudytonight - Best place to learn\n\n\n");
boolean Vowel=false;

            Scanner scanner = new Scanner(System.in);
            try{
            System.out.println("Input a Character :  ");
            char ch = scanner.next().charAt(0);
            switch (ch) {
                    case 'a':
                    case 'A':
                    case 'e':
                    case 'E':
                    case 'i':
                    case 'I':
                    case 'o':
                    case 'O':
                    case 'u':
                    case 'U':
                        Vowel=true;
                        }
                        if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
                            System.out.println(ch + " is not a vowel.\n\n");
                        } else if(Vowel==true) {
                            System.out.println(ch + " is  a vowel.\n\n");
                        }
                        else{
                            throw new Exception();
                        }

            } catch (java.lang.Exception e) {
                System.out.println("not alphabet");
            }
        System.out.println("\n\n\t\t\tCoding is Fun !\n\n\n");
        }
    }

