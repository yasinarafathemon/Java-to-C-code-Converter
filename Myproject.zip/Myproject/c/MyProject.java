import javax.swing.*; 
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner; 

public class MyProject extends JFrame  { 
	
   private JButton ListofPrograms = new JButton("List of Programs(21)");
	
	
   private JButton BtnBasicPrograms = new JButton("Basic Programs(3)");    
   private JButton Btnreversingcharacter = new JButton("Reversing Character"); 
   private JButton BtnCheckingforgrade = new JButton("Checking for grade"); 
   private JButton BtnCheckingforvowel = new JButton("Checking For Vowel ");
   
   
   private JButton BtnLoops = new JButton("Loops(5)");
   private JButton Btnprogramtofindfactorialofnumber= new JButton("Program to find factorial of number(for loop)");
   private JButton Btnhowtoreverseastringusingforloop = new JButton("How to reverse  a string(for loop)");
   private JButton Btnfibonacciseriesdowhileloop = new JButton("Fibonacci  series(do while loop)");
   private JButton Btnprogramtofindsumofdigitwhileloop = new JButton("Program to find sum of digit(while loop)");
   private JButton Btnpalindromeseriesprogramwhileloop= new JButton("Palindrome series program(while loop)");
   
   
   private JButton BtnNumbercrunching = new JButton("Number Crunching(3)"); 
   private JButton Btnprintfactorofanumber= new JButton("Print factor of a number"); 
   private JButton Btnprogramtoprintthemultiplicationtableofanynumber = new JButton("Program to print the multiplication"
   		+ " table of any number"); 
   private JButton BtnExponential = new JButton("Exponential"); 
   
   
   private JButton BtnConceptofarrays = new JButton("Concept of Arrays (5)"); 
   private JButton BtnReverseanArray = new JButton("Reverse an Array");
   private JButton BtnInsertElementtoArray = new JButton("Insert Element to Array");
   private JButton BtnDeleteElementfromArray = new JButton("Delete Element from Array");
   private JButton BtnLargestandSmallestElementinArray = new JButton("Largest and Smallest Element in Array");
   private JButton BtnSumofNNumbersusingArrays = new JButton("Sum of N Numbers using Arrays");
   
   
   private JButton BtnConceptofRecursion= new JButton("Concept of Recursion (2)"); 
   private JButton BtnSumofFirstNNumbers= new JButton("Sum of First N Numbers");
   private JButton BtnFactorial= new JButton("Factorial");
   
   
   private JButton BtnMiscellaneous= new JButton("Miscellaneous (3)"); 
   private JButton BtnLeapyear= new JButton("Leap Year"); 
   private JButton BtnLargestofthreenumbers= new JButton("Largest of three numbers"); 
   private JButton BtnSecondlargestamongthreenumbers= new JButton("Second largest among three numbers"); 
 
   
   
   private JButton BtnThree = new JButton("Three"); 
   private JButton BtnFour = new JButton("Four"); 
   private JButton BtnFive = new JButton("Five"); 
   private JButton BtnSix = new JButton("Six"); 
   private JButton BtnSvn = new JButton("Seven"); 
   private JButton BtnEight = new JButton("Eight"); 
   private JButton BtnNine = new JButton("Nine"); 
   private JButton BtnTen = new JButton("Ten"); 
   private JButton BtnElvn = new JButton("Eleven"); 
   private JButton BtnTwlv = new JButton("Twelve"); 

   JTextArea taC = new JTextArea();///// object for c text area
   JTextArea taJ = new JTextArea();///// object for java text area

   
   private JPanel panelLeft = new JPanel(new GridLayout(0, 1)); ///set row and colum
   private JPanel panelRight = new JPanel(new GridLayout(1,2));
   
   
   public MyProject() { 

	  setLayout(new BorderLayout()); 
	  setSize(1300, 800); 
	  
	  panelLeft.add(ListofPrograms);
	  
      panelLeft.add(BtnBasicPrograms);
      panelLeft.add(BtnCheckingforvowel);
      panelLeft.add(Btnreversingcharacter);
      panelLeft.add(BtnCheckingforgrade);
      
      
      panelLeft.add(BtnLoops);
      panelLeft.add(Btnprogramtofindfactorialofnumber);
      panelLeft.add(Btnhowtoreverseastringusingforloop);
      panelLeft.add(Btnfibonacciseriesdowhileloop);
      panelLeft.add(Btnprogramtofindsumofdigitwhileloop);
      panelLeft.add(Btnpalindromeseriesprogramwhileloop);
      
      panelLeft.add(BtnNumbercrunching);
      panelLeft.add(Btnprintfactorofanumber);
      panelLeft.add(Btnprogramtoprintthemultiplicationtableofanynumber);
      panelLeft.add(BtnExponential);
      
      panelLeft.add(BtnConceptofarrays);
      panelLeft.add(BtnReverseanArray);
      panelLeft.add(BtnInsertElementtoArray);
      panelLeft.add(BtnDeleteElementfromArray);
      panelLeft.add(BtnLargestandSmallestElementinArray);
      panelLeft.add(BtnSumofNNumbersusingArrays);
      
      panelLeft.add(BtnConceptofRecursion);
      panelLeft.add(BtnSumofFirstNNumbers);
      panelLeft.add(BtnFactorial);
     
      panelLeft.add(BtnMiscellaneous);
      panelLeft.add(BtnLeapyear);
      panelLeft.add(BtnLargestofthreenumbers);
      panelLeft.add(BtnSecondlargestamongthreenumbers);
     
      
      JScrollPane scrollC = new JScrollPane(taC);  
      JScrollPane scrollJ = new JScrollPane(taJ); 
      JScrollPane scrollL = new JScrollPane();  ///for scroll pane
//      taC.setBounds(10, 30, 600, 640);   ///declaring height and weight for c text area
      panelRight.add(scrollC); /// adding textarea to panel for c
      
//      taJ.setBounds(10, 30, 600, 640);   ///declaring height and weight for c text area
      panelRight.add(scrollJ); /// adding textarea to panel for java
      panelLeft.add(scrollL);
      
      //      String data=readFile("D:\\practice.c");
//      taC.setText(data);
      
	  add(panelLeft, BorderLayout.WEST); 
	  add(panelRight, BorderLayout.CENTER); 
	  
	  							///BASIC PROGRAM
	  
	  Btnreversingcharacter.addActionListener(new ActionListener() {		
	   		
	   		@Override
	   		public void actionPerformed(ActionEvent e) {	 ///performing button click code show action	
	            System.out.println("C program"); 
	   			String data=readFile("C:\\c\\ReversingCharacter.c");
	   	      taC.setText(data);	
	   	   System.out.println("java program"); 
	   	   data=readFile("C:\\java\\ReversingCharacter.java ");
		      taJ.setText(data);
	   		}
	   	});
	  BtnCheckingforgrade.addActionListener(new ActionListener() {		
		
		@Override
		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
          String data=readFile("C:\\c\\CheakingForGrade.c");
	      taC.setText(data);	
	      data=readFile("C:\\java\\CheakingForGrade.java");
	      taJ.setText(data);
		}
	});
       BtnCheckingforvowel.addActionListener(new ActionListener() {		
   		
   		@Override
   		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
             String data=readFile("C:\\c\\CheakingForVowel.c");
   	      taC.setText(data);	
   	   data=readFile("C:\\java\\CheakingForVowel.java ");
	      taJ.setText(data);
   		}
   	});
       
       
       
       						///LOOPS
       
       
       Btnprogramtofindfactorialofnumber.addActionListener(new ActionListener() {		
      		
      		@Override
      		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
                String data=readFile("C:\\c\\FactorialNumber.c");
      	      taC.setText(data);	
      	   data=readFile("C:\\java\\FactorialNumber.java ");
   	      taJ.setText(data);
      		}
      	});
       Btnhowtoreverseastringusingforloop.addActionListener(new ActionListener() {		
      		
      		@Override
      		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
                String data=readFile("C:\\c\\ReverseAString.c");
      	      taC.setText(data);	
      	   data=readFile("C:\\java\\ReverseAString.java ");
   	      taJ.setText(data);
      		}
      	});
       Btnfibonacciseriesdowhileloop.addActionListener(new ActionListener() {		
      		
      		@Override
      		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
                String data=readFile("C:\\c\\FibonacciSeries.c");
      	      taC.setText(data);	
      	   data=readFile("C:\\java\\FibonacciSeries.java ");
   	      taJ.setText(data);
      		}
      	});
       Btnprogramtofindsumofdigitwhileloop.addActionListener(new ActionListener() {		
      		
      		@Override
      		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
                String data=readFile("C:\\c\\SumOfDigit.c");
      	      taC.setText(data);	
      	   data=readFile("C:\\java\\SumOfDigit.java ");
   	      taJ.setText(data);
      		}
      	});
       Btnpalindromeseriesprogramwhileloop.addActionListener(new ActionListener() {		
      		
      		@Override
      		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
                String data=readFile("C:\\c\\PalindromeProgram.c");
      	      taC.setText(data);	
      	   data=readFile("C:\\java\\PalindromeProgram.java ");
   	      taJ.setText(data);
      		}
      	});
       
       				///NUMBER CRUNCHING
       
       Btnprintfactorofanumber.addActionListener(new ActionListener() {		
      		
      		@Override
      		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
                String data=readFile("C:\\c\\FactorOfNumber.c");
      	      taC.setText(data);	
      	   data=readFile("C:\\java\\FactorOfNumber.java ");
   	      taJ.setText(data);
      		}
      	});
       Btnprogramtoprintthemultiplicationtableofanynumber.addActionListener(new ActionListener() {		
     		
     		@Override
     		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
               String data=readFile("C:\\c\\MultiplicationTable.c");
     	      taC.setText(data);	
     	   data=readFile("C:\\java\\MultiplicationTable.java ");
  	      taJ.setText(data);
     		}
     	});
       BtnExponential.addActionListener(new ActionListener() {		
     		
     		@Override
     		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
               String data=readFile("C:\\c\\Exponential.c");
     	      taC.setText(data);	
     	   data=readFile("C:\\java\\Exponential.java ");
  	      taJ.setText(data);
     		}
     	});
     
       					///CONCEPT OF ARRAYS
       BtnReverseanArray.addActionListener(new ActionListener() {		
     		
     		@Override
     		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
               String data=readFile("C:\\c\\ReverseAnArray.c");
     	      taC.setText(data);	
     	   data=readFile("C:\\java\\ReverseAnArray.java ");
  	      taJ.setText(data);
     		}
     	});
       BtnInsertElementtoArray.addActionListener(new ActionListener() {		
     		
     		@Override
     		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
               String data=readFile("C:\\c\\InsertElementToArray.c");
     	      taC.setText(data);	
     	   data=readFile("C:\\java\\InsertElementToArray.java ");
  	      taJ.setText(data);
     		}
     	});
       BtnDeleteElementfromArray.addActionListener(new ActionListener() {		
     		
     		@Override
     		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
               String data=readFile("C:\\c\\DeleteElementsFromArray.c");
     	      taC.setText(data);	
     	   data=readFile("C:\\java\\DeleteElementsFromArray.java ");
  	      taJ.setText(data);
     		}
     	});
       BtnLargestandSmallestElementinArray.addActionListener(new ActionListener() {		
     		
     		@Override
     		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
               String data=readFile("C:\\c\\LargestSmallestNumber.c");
     	      taC.setText(data);	
     	   data=readFile("C:\\java\\LargestSmallestNumber.java ");
  	      taJ.setText(data);
     		}
     	});
       BtnSumofNNumbersusingArrays.addActionListener(new ActionListener() {		
    		
     		@Override
     		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
               String data=readFile("C:\\c\\SumOfNNumberArray.c");
     	      taC.setText(data);	
     	   data=readFile("C:\\java\\SumOfNNumberArray.java ");
  	      taJ.setText(data);
     		}
     	});
       
       						///CONCEPT OF RECURSION
      
       BtnSumofFirstNNumbers.addActionListener(new ActionListener() {		
    		
     		@Override
     		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
               String data=readFile("C:\\c\\Sum Of First N Numbers.c");
     	      taC.setText(data);	
     	   data=readFile("C:\\java\\Sum Of First N Numbers.java ");
  	      taJ.setText(data);
     		}
     	});
       BtnFactorial.addActionListener(new ActionListener() {		
    		
     		@Override
     		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
               String data=readFile("C:\\c\\Factorial.c");
     	      taC.setText(data);	
     	   data=readFile("C:\\java\\Factorial.java ");
  	      taJ.setText(data);
     		}
     	});
       
       						///misscellaneous
       
      
       BtnLeapyear.addActionListener(new ActionListener() {		
    		
     		@Override
     		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
               String data=readFile("C:\\c\\LeapYear.c");
     	      taC.setText(data);	
     	   data=readFile("C:\\java\\LeapYear.java ");
  	      taJ.setText(data);
     		}
     	});
       BtnLargestofthreenumbers.addActionListener(new ActionListener() {		
    		
     		@Override
     		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
               String data=readFile("C:\\c\\LargestOfThreeNumber.c");
     	      taC.setText(data);	
     	   data=readFile("C:\\java\\LargestOfThreeNumber.java ");
  	      taJ.setText(data);
     		}
     	});
       BtnSecondlargestamongthreenumbers.addActionListener(new ActionListener() {		
   		
    		@Override
    		public void actionPerformed(ActionEvent e) {	  ///performing button click code show action	
              String data=readFile("C:\\c\\SecondLargestAmongThreeNum.c");
    	      taC.setText(data);	
    	   data=readFile("C:\\java\\SecondLargestAmongThreeNum.java ");
 	      taJ.setText(data);
    		}
    	});
       
       setVisible(true);
//		 
//		  
//		  JScrollPane scrollC = new JScrollPane(taC); 
//   	  JScrollPane scrollJ = new JScrollPane(taJ);		  
//		 
//		  panelRight.add(scrollC); panelRight.add(scrollJ);
//	  
//		  add(panelLeft, BorderLayout.WEST); 
//	      add(panelRight, BorderLayout.CENTER);
//		  
//		  BtnHW.addActionListener(new ActionListener() {
//	
//	      @Override public void actionPerformed(ActionEvent e) { String data =
//		  readFile("D:\\EWU\\cse489\\hello.c"); taC.setText(data); data =
//		  readFile("D:\\EWU\\cse489\\hello.java"); taJ.setText(data); } });
//		  
//		  BtnIfElse.addActionListener(new ActionListener() {
//		  
//		  @Override public void actionPerformed(ActionEvent e) { String data =
//		  readFile("D:\\EWU\\cse489\\ifelse.c"); taC.setText(data); taJ.setText(""); }
//		 });
//		 

  }
  
  public  String readFile(String filePath) { 
	  try {
//		  int a=5;
//		  int b=0;
//		  int c=a/b;
//		  
		  
	      File myObj = new File(filePath);
	      Scanner myReader = new Scanner(myObj); 
	      String fileData = "";
	      while (myReader.hasNextLine()) {
	    	  fileData += myReader.nextLine()+"\n";
	      }
	      //System.out.println(fileData);
	      myReader.close();
	      return fileData;
	    }catch (FileNotFoundException ex) {
		      System.out.println("FileNotFoundException occurred.");
		      ex.printStackTrace();
		}
//	     catch (NullPointerException ex) {
//	      System.out.println("NullPointerException occurred.");
//	      ex.printStackTrace();
//	    }
//	     catch (IndexOutOfBoundsException ex) {
//	      System.out.println("IndexOutOfBoundsException occurred.");
//	      ex.printStackTrace();
//	    }
//	     catch (Exception ex) {
//	      System.out.println("Exception occurred.");
//	      ex.printStackTrace();
//	    }
//	     catch (ArithmeticException ex) {
//
//		  System.out.println("ArithmeticException occurred.");	      
//		  ex.printStackTrace();
//	    }
	   return null;
   }
}

//   public static void main(String[] args) {
//	   
////	   String data=readFile("D://practice.c");
////	   System.out.println(data);
//	   new MyProject();
//   } 
//}

